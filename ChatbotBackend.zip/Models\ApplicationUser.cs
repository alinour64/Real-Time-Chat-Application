using Microsoft.AspNetCore.Identity;

namespace ChatbotBackend.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
